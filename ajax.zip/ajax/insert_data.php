<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1 style="text-align: center; margin:30px;">Add From Ajax</h1>
        <div  class="error-mess"></div>
        <div class="sussces-mess"></div>
        <div class="form-diplay" style="   ">
        <form  id="addForm"  style="    justify-content: center;
    display: flex;">
            <div class="form" style=" ">
            <div style="padding: 10px 20px;">
            <label for="">first name</label>
            <input type="text" id="fname" style="">
            </div>

            <div class="form" style="padding: 10px 20px;">
                <label for="">last name</label>
                <input type="text" id="lname">
            </div>
            
                        <input type="submit" value="save" style="height: 31px;
    margin-top: 13px;
    margin-left:40px;
    width: 84px;
    background-color:#2e2e53;
    color: white; border-radius:10px" id="save-button">

            </div>



        </form>
        
        </div>
        <div id="search-bar" style=" display: flex;
    justify-content: end;margin:20px   ">
            <label  style="font-size: 20px; margin:0px 10px" >search</label>
            <input type="text" id="search" autocomplete="off" style=" border-radius: 5px; width:277px ">
        </div>

     <div id="info">
        
     </div>
     <div class="container">
    
     </div>
      <div>
        <!-- Button trigger modal -->


        <!-- Modal -->
        <div class="modal fade" id="modalOp" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Edit form</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  
              </div>
              
            </div>
          </div>
        </div>
     </div>
     </div> 
     
     

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  
<script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
    </script>
    <script>
        // loadTable data

        $(document).ready(function(){
         function loadTable(){
            $.ajax({
            url : "ajax_load.php",
            typr : "post",
            success : function(data){
                $('#info').html(data);
            }
         });
         }
         loadTable();
         
        //  insert data

         $("#save-button").on("click",function(e){
             e.preventDefault();
             var fname = $("#fname").val();
             var lname = $("#lname").val();

             if(fname == "" && lname == ""){
              alert("please all filed required");
             }else{

             $.ajax({
                url : "ajax_insert.php",
                type : "POST",
                data : {first_name : fname , last_name: lname},
                success : function(data){
                    if(data = 1){

                        loadTable();
                        $("#addForm").trigger('reset');

                    }
                    else{
                        alert("cant save record");
                    }
                     
                }
             });
            }
            
         });

        //  delete data
         $(document).on("click",".delete",function(){ 
         if(confirm("are you really want this record delete ? ")){  
            var studentId = $(this).data("id");
            var element = this;
            $.ajax({
                url:"ajax_delete.php",
                type:"POST",
                data: {id:studentId},
                success : function(data){
                    if(data == 1){
                        $(element).closest("tr").fadeOut();

                    }
                    else{
                        $(".error-mess").html("cant delete record").slideDown();
                        $(".sussces-mess").slideUp();
                        
                    }
                }

            });
            } 

         });

        //  update-fetch val data
        $(document).on("click",".edit",function(){
            $("#modalOp").show();
            var studentId = $(this).data("eid");
            // alert(studentId);
            
             $.ajax({
                url:"ajax_update.php",
                type:"GET",
                data:{id:studentId},
                success:function(data){
                     
                    $(".modal-body").html(data);
                    
                }
             });

        });
    
        // update value chnge data

        $(document).on("click", "#edit-submit", function(){
        //   e.preventDefault();  
          var stuId = $(".edit-id").val();
          var fname = $(".edit-fname").val();
          var lname = $(".edit-lname").val();
          $.ajax({
              url:"update_insert.php",
              type:"POST",
              data:{id: stuId, first_name: fname, last_name: lname},
              success:function(data){
                // alert("Response from server: " + data);
                if(data == 1){

                loadTable();
                   
                } 
                  
                
              }
               
          });
          
        });

        // search bar
        $("#search").on("keyup",function(){
          var search_term = $(this).val();
          $.ajax({
            url :"ajax-live-search.php",
            type:"POST",
            data:{search:search_term},
            success:function(data){
             $("#info").html(data);

            }

          });

        });

        // paggination method

        function loadTable(page){
          // alert(page);
          $.ajax({
            url:"ajax.pagination.php",
            type:"POST",
            data:{page_no:page},
            success:function(data){
              
              $("#info").html(data);


            }
          });
        }
        loadTable();

        $(document).on("click" ,"#pagination li a",function(e){
         e.preventDefault();
         var page_id =$(this).attr("id");
         loadTable(page_id);
        //  alert(page_id);
        });


        });
    </script>
</html>