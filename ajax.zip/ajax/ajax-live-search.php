<?php

$search_value = $_POST['search'];

$conn = mysqli_connect("localhost","root","","emp") or die("not connnection");

$sql = "SELECT * FROM `new_ajax` WHERE first_name LIKE '%{$search_value}%' OR last_name LIKE '%{$search_value}%'";
$output = "";

$result = mysqli_query($conn,$sql) or die("sql query is failed");

if(mysqli_num_rows($result)>0){
    $output = '<table border = "1" width = "100%" cellspacing ="0" cellpadding= "10px " >

        <tr>
            <th>id</th>
            <th>first name </th>
            <th> last name </th>
            <th>edit</th>
            <th> delete </th>
        </tr>
        

    
    
    ';
    while($row = mysqli_fetch_assoc($result)){
        $output.="
        <tr>
          <td>{$row["id"]}</td>
          <td>{$row["first_name"]}</td>
          <td>{$row["last_name"]}</td>
          <td><button type='button' data-eid='{$row["id"]}' class='btn btn-primary edit'  data-bs-toggle='modal' data-bs-target='#modalOp'>
          edit
        </button></td>
          <td><button type='button' data-id='{$row["id"]}' class='btn delete btn-danger'>delete</button></td>


        </tr>
        ";
    }

    $output .="</table>";

    mysqli_close($conn);

    echo $output;
}
else {
    echo "<h2>no record found</h2>";
}










?>