<?php

$studentId = $_GET["id"];
 
 

$conn = mysqli_connect("localhost","root","","emp") or die("connection failed");



$sql = "SELECT * FROM `new_ajax` WHERE id = {$studentId}";
$output = "";   
$result = mysqli_query($conn,$sql) or die("conmection failed");

if(mysqli_num_rows($result)>0){
     
    while($row = mysqli_fetch_assoc($result)){
        $output.="
        <form>
        <div class='mb-3'>
            <label for='exampleInputEmail1' class='form-label'>first name</label>
            <input type='text' class='form-control edit-fname' id='exampleInputEmail1 ' aria-describedby='emailHelp' value='{$row["first_name"]}'  >
            <input type='text' class='form-control edit-id' id='exampleInputEmail1 ' aria-describedby='emailHelp' hidden value='{$row["id"]}'  >
          
        </div>
        <div class='mb-3'>
            <label for='exampleInputPassword1' class='form-label'>Last name</label>
            <input type='text' class='form-control edit-lname' id='exampleInputPassword1 ' value='{$row["last_name"]}' >
        </div>
        
        <button type='submit' class=' btn btn-primary ' id='edit-submit'>Submit</button>
        </form>
         
        ";
    }

     

    mysqli_close($conn);

    echo $output;
}






?>
