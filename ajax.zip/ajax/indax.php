<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
         
    </style>
</head>
<body> 

    <div style="padding: 100px;">
        <input type="button " id= "load-data" value="select">
    </div>

   <div id="info" >
    
   </div>
    
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
    </script>

    <script>
        $(document).ready(function(){
           $('#load-data').on("click",function(e){
  
          
         $.ajax({
            url : "ajax_load.php",
            typr : "GET",
            success : function(data){
                $('#info').html(data);
            }
         });
        
        }); 
        });
    </script>
</html>