<?php 

$studentId = $_POST["id"];

$conn = mysqli_connect("localhost","root","","emp") or die("connection failed");

$sql = "DELETE FROM `new_ajax` WHERE `new_ajax`.`id` ={$studentId}";

if(mysqli_query($conn,$sql)){
    echo 1;
}
else{
    echo 0;
}






?>