<?php 

$studentId = $_POST["id"];
$firstName = $_POST["first_name"];
$lastName = $_POST["last_name"];

$conn = mysqli_connect("localhost","root","","emp") or die("connection failed");

$sql = "UPDATE `new_ajax` SET `first_name` = '{$firstName}', `last_name` = '{$lastName}' WHERE `new_ajax`.`id` = {$studentId}";

if(mysqli_query($conn,$sql)){
    echo 1;
}
else{
    echo 0;
}
// $sql = "UPDATE `new_ajax` SET `first_name` = ?, `last_name` = ? WHERE `id` = ?";

// $stmt = mysqli_prepare($conn, $sql);
// mysqli_stmt_bind_param($stmt, "ssi", $firstName, $lastName, $student_Id);

// if (mysqli_stmt_execute($stmt)) {
//     echo 1;
// } else {
//     echo 0;
// }

// mysqli_stmt_close($stmt);
// mysqli_close($conn);






?>